/*
 *  ImageGenerator.h
 *  Computergrafik2
 *
 *  Created by Hartmut Schirmacher on 9/22/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef IMAGEGENERATOR_H
#define IMAGEGENERATOR_H

// forward declarations
class Painter;
class QString;


/**
 * Generate an image to specification and save it to disk in PNG format.
 */
class ImageGenerator {
	
public:
	
	/**
	 * Instantiate a generator for the specified painter object with supplied size
	 * and filename.
	 * 
	 * @param painter
	 *          The painter object.
	 * @param resolutionX
	 *          Image width in pixels.
	 * @param resolutionY
	 *          Image height in pixels.
	 * @param filename
	 *          File to store the image in.
	 * @param imgformat
	 *          String describing the desired image format. Supported formats: "png".
	 */
	ImageGenerator(const Painter& painter, 
				   int resolutionX, 
				   int resolutionY, 
				   const QString& filename, 
				   const QString& imgformat);
	
	/**
	 * Convenience function - try to open an appropriate viewer and show the image file.
	 */
        static bool showImage(const QString& filename);

private:
	
        /** helper function, returns true if file has been written successfully **/
        bool generate(const Painter& painter, int resolutionX, int resolutionY,
                      const QString& filename, const QString& imgformat) const;
};

#endif
