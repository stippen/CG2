/*
 *  Painter.h
 *  Computergrafik2
 *
 *  Created by Hartmut Schirmacher on 9/22/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef PAINTER_H
#define PAINTER_H

#include <QColor>

/**
 * The abstract Painter interface specifies how an image should be painted pixel by pixel.
 */
class Painter {
	
public:
	/**
	 * Override to determine the pixel color for one pixel of the image.
	 * 
	 * @param i
	 *          The index of the pixel in X direction.
	 * @param j
	 *          The index of the pixel in Y direction.
	 * @param resolutionX
	 *          The image width in pixels.
	 * @param resolutionY
	 *          The image height in pixels.
	 * @return The pixel color
	 */
	virtual QColor pixelColorAt(int i, int j, int resolutionX, int resolutionY) const = 0;
};

#endif
