/*
 *  Checkerboard.cpp
 *  Test
 *
 *  Created by Hartmut Schirmacher on 9/22/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#include "Checkerboard.h"

QColor Checkerboard::pixelColorAt(int i, int j, int resolutionX, int resolutionY) const
{
	
    // this is just a little hint -
    // but not yet the solution to paint an 8x8 checkerboard for any given resolution
    if(i % 2 + j % 2 == 1) {
        return QColor(0, 0, 0);
    } else {
        return QColor(255, 255, 255);
    }

}

