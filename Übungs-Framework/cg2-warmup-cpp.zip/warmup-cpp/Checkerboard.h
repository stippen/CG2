/*
 *  Checkerboard.h
 *  Test
 *
 *  Created by Hartmut Schirmacher on 9/22/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef CHECKERBOARD_H
#define CHECKERBOARD_H

#include "Painter.h"  // base class

// paints an 8x8 checkerboard, pixel by pixel
class Checkerboard: public Painter {
	
public:
	
	virtual QColor pixelColorAt(int i, int j, int width, int height) const;
	
};

#endif
