/*
 *  Warmup.cpp
 *  Computergrafik2
 *
 *  Created by Hartmut Schirmacher on 9/22/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#include "Warmup.h"

#include "ImageGenerator.h"
#include "Checkerboard.h"

#include "QDir"

// simple test program that will generate two image files 
int main() {

    // path to the user's home directory, should work for all operating systems
    QString path = QDir::homePath();
		
    // ************ test painting a checkerboard ************
    {
        QString filename(path + "/" + "checkerboard.png");
        ImageGenerator(Checkerboard(), 550, 550, filename, "png");
        ImageGenerator::showImage(filename);
    }

    // ************ test painting a disk ************
    {
        // ...
    }

    return 0;
}
