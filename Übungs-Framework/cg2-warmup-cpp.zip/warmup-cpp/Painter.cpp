/*
 *  Painter.cpp
 *  Computergrafik2
 *
 *  Created by Hartmut Schirmacher on 9/22/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#include "Painter.h"

/* this file is empty - the painter interface does not implement anything yet */
