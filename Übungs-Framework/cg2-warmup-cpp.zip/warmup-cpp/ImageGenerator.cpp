/*
 *  ImageGenerator.cpp
 *  Computergrafik2
 *
 *  Created by Hartmut Schirmacher on 9/22/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#include "ImageGenerator.h"
#include "Painter.h" // painter methods are called from within ImageGenerator

// include required functionality from Qt library
#include <QString>
#include <QFile>
#include <QImage>
#include <QDesktopServices>
#include <QUrl>
#include <QColor>

#include <QDebug> // for error handling

ImageGenerator::ImageGenerator(const Painter& painter, int width, int height, 
                               const QString& filename, const QString& imgformat)
{
	generate(painter,width,height,filename,imgformat);
}
	

// note: this is a static function, not a class method
bool ImageGenerator::showImage(const QString& filename)
{
	QUrl url = QUrl::fromLocalFile(QString(filename));
        return QDesktopServices::openUrl(url);
}

bool ImageGenerator::generate(const Painter& painter, int resolutionX, int resolutionY,
                              const QString& filename, const QString& imgformat) const
{
    // create a buffered image object using RGB+A pixel format
    QImage img(resolutionX, resolutionY, QImage::Format_ARGB32);
	
    // Set a color for each pixel. Y pixel indices are flipped so that the origin (0,0)
    //   is at the bottom left of the image.
    for (int i = 0; i < resolutionX; i++)
        for (int j = 0; j < resolutionY; j++)
            img.setPixel(i,j, painter.pixelColorAt(i, resolutionY-j-1, resolutionX, resolutionY).rgb() );
	
    // Write the image to disk.
    if(!img.save(filename, qPrintable(imgformat))) {
        qCritical() << "ERROR: could not write image file " << filename;
        return false;
    }

    return true;
}
